package com.fis.bankapplication.exceptions;

public class CustomerNotFound extends Exception {// To get an user friendly message whenever there is an exception

	public CustomerNotFound(String message) {
		super(message);
	}

}
