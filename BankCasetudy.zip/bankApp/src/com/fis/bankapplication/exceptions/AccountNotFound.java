package com.fis.bankapplication.exceptions;

public class AccountNotFound extends Exception {// To get an user friendly message whenever there is an exception

	public AccountNotFound(String message) {
		super(message);
	}

}
