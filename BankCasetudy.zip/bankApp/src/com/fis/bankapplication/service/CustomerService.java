package com.fis.bankapplication.service;

import java.util.Set;

import com.fis.bankapplication.beans.Customer;
import com.fis.bankapplication.exceptions.CustomerNotFound;

public interface CustomerService {// Interface class with all the methods as abstract
	public abstract String addCustomer(Customer customer);

	public abstract String updateCustomer(Customer customer) throws CustomerNotFound;

	public abstract String deleteCustomer(int custId) throws CustomerNotFound;

	public abstract Customer getCustomer(int custId) throws CustomerNotFound;

	public abstract Set<Customer> getAllCustomers();

}
