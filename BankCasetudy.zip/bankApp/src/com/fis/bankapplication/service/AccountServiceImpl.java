package com.fis.bankapplication.service;

import com.fis.bankapplication.beans.Account;
import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.exceptions.NotEnoughBalance;
import com.fis.bankapplication.repo.AccountRepo;
import com.fis.bankapplication.repo.AccountRepoImpl;

public class AccountServiceImpl implements AccountService {// child class of interface where the implementation is done
	AccountRepo dao = new AccountRepoImpl();

	@Override
	public String addAccount(Account account) {
		return dao.addAccount(account);

	}

	@Override
	public String deleteAccount(long accNo) throws AccountNotFound {

		return dao.deleteAccount(accNo);
	}

	@Override
	public Account getAccount(long getAcc) throws AccountNotFound {
		return dao.getAccount(getAcc);

	}

	@Override
	public void withdrawFromBalance(long getAcc, double withdrawAmount) throws NotEnoughBalance {

		dao.withdrawFromBalance(getAcc, withdrawAmount);
	}

	@Override
	public void depositIntoBalance(long getAcc, double depositAmount) {

		dao.depositIntoBalance(getAcc, depositAmount);
	}

}
