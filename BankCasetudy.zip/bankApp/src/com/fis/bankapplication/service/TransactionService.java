package com.fis.bankapplication.service;

import java.util.ArrayList;

import com.fis.bankapplication.beans.Transaction;

public interface TransactionService {// Interface class with all the methods as abstract

	public abstract String addDeposit(long dpAccNo, Transaction transaction);

	public abstract String addWithdraw(long wdAccNo, Transaction transaction);

	public abstract String addTransactionNEFT(long transFromAcc, long neftAccNo, Transaction transaction);

	public abstract ArrayList<String> getTransForAccNo(Transaction transaction, long showTransAccNo);
}
