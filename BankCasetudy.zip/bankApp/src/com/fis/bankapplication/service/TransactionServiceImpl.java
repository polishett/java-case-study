package com.fis.bankapplication.service;

import java.util.ArrayList;

import com.fis.bankapplication.beans.Transaction;
import com.fis.bankapplication.repo.TransactionRepo;
import com.fis.bankapplication.repo.TransactionRepoImpl;

public class TransactionServiceImpl implements TransactionService {// child class of interface where the implementation
																	// is done
	TransactionRepo dao = new TransactionRepoImpl();

	@Override
	public String addDeposit(long dpAccNo, Transaction transaction) {
		return dao.addDeposit(dpAccNo, transaction);
	}

	@Override
	public String addWithdraw(long wdAccNo, Transaction transaction) {
		return dao.addWithdraw(wdAccNo, transaction);
	}

	@Override
	public String addTransactionNEFT(long transFromAcc, long neftAccNo, Transaction transaction) {
		return dao.addTransactionNEFT(transFromAcc, neftAccNo, transaction);
	}

	@Override
	public ArrayList<String> getTransForAccNo(Transaction transaction, long showTransAccNo) {
		return dao.getTransForAccNo(transaction, showTransAccNo);
	}

}
