package com.fis.bankapplication.service;

import java.util.Set;

import com.fis.bankapplication.beans.Customer;
import com.fis.bankapplication.exceptions.CustomerNotFound;
import com.fis.bankapplication.repo.CustomerRepo;
import com.fis.bankapplication.repo.CustomerRepoImpl;

public class CustomerServiceImpl implements CustomerService {// child class of interface where the implementation is
																// done

	CustomerRepo dao = new CustomerRepoImpl();

	@Override
	public String addCustomer(Customer customer) {
		return dao.addCustomer(customer);
	}

	@Override
	public String updateCustomer(Customer customer) throws CustomerNotFound {

		return dao.updateCustomer(customer);
	}

	@Override
	public String deleteCustomer(int custId) throws CustomerNotFound {

		return dao.deleteCustomer(custId);
	}

	@Override
	public Customer getCustomer(int custId) throws CustomerNotFound {

		return dao.getCustomer(custId);
	}

	@Override
	public Set<Customer> getAllCustomers() {

		return dao.getAllCustomers();
	}

}
