package com.fis.bankapplication.repo;

import com.fis.bankapplication.beans.Account;
import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.exceptions.NotEnoughBalance;

public interface AccountRepo {//Interface class with all the methods as abstract
	public abstract String addAccount(Account account);

	
	public abstract String deleteAccount(long accNo) throws AccountNotFound;

	public abstract Account getAccount(long getAcc) throws AccountNotFound;
	
	public abstract void withdrawFromBalance(long getAcc, double withdrawAmount) throws NotEnoughBalance;

	public abstract void depositIntoBalance(long getAcc, double depositAmount);

}
