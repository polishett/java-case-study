package com.fis.bankapplication.repo;

import java.util.ArrayList;

import com.fis.bankapplication.beans.Transaction;

public interface TransactionRepo {
	
	public abstract String addDeposit(long dpAccNo, Transaction transaction);

	public abstract String addWithdraw(long wdAccNo, Transaction transaction);
	
	public abstract String addTransactionNEFT(long transFromAcc, long neftAccNo, Transaction transaction);
	
	public abstract ArrayList<String> getTransForAccNo(Transaction transaction, long showTransAccNo);

}
