package com.fis.bankapplication.repo;

import java.util.ArrayList;
import java.util.HashMap;

import com.fis.bankapplication.beans.Transaction;

public class TransactionRepoImpl implements TransactionRepo{

	HashMap<Long, Transaction> clientAccTransactions = new HashMap<Long, Transaction>();
	ArrayList<String> allTrans = new ArrayList<String>();
	
	
	@Override
	public String addDeposit(long dpAccNo, Transaction transaction) {
		
		clientAccTransactions.put(dpAccNo, transaction);
		clientAccTransactions.put(dpAccNo, transaction);
		
		System.out.println("Successfully deposited to " + dpAccNo 
				+ " with TransactionID " + transaction.getTransId());
		
		return "Transaction Added to Account Transaction History";
	}
	
	@Override
	public String addWithdraw(long wdAccNo, Transaction transaction) {
		
		clientAccTransactions.put(wdAccNo, transaction);
		clientAccTransactions.put(wdAccNo, transaction);
		
		System.out.println("Successfully withdrawn from " + wdAccNo 
				+ " with TransactionID " + transaction.getTransId());
		
		return "Transaction Added to Account Transaction History";
	}


	
	@Override
	public String addTransactionNEFT(long transFromAcc, long neftAccNo, Transaction transaction) {
		
		clientAccTransactions.put(transFromAcc, transaction);
		clientAccTransactions.put(neftAccNo, transaction);
		
		System.out.println("Successfully transferred from " + transFromAcc + " to " + neftAccNo 
				+ " with TransactionID " + transaction.getTransId());
		
		return "Transaction Added to Account Transaction History";
	}

	@Override
	public ArrayList<String> getTransForAccNo(Transaction transaction, long showTransAccNo) {
		
		while(true) {
			if (transaction.getAccNoFrom() == showTransAccNo) {
				allTrans.add(transaction.toString());
			}
			if (transaction.getAccNoTo() == showTransAccNo) {
				allTrans.add(transaction.toString());
			}
			return allTrans;
		}
	}

}
