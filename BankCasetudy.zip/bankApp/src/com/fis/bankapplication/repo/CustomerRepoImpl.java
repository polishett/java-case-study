package com.fis.bankapplication.repo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.fis.bankapplication.beans.Customer;
import com.fis.bankapplication.exceptions.CustomerNotFound;

public class CustomerRepoImpl implements CustomerRepo {

	HashMap<Integer, Customer> customers = new HashMap<Integer, Customer>();

	@Override
	public String addCustomer(Customer customer) {
		customers.put(customer.getcustId(), customer);
		return "Customer Registered Successfully";
	}

	@Override
	public String updateCustomer(Customer customer) throws CustomerNotFound {// 123
		if (customers.containsKey(customer.getcustId())) {
			customers.put(customer.getcustId(), customer);
			return "Customer Updated Successfully";
		} else {
			throw new CustomerNotFound("Invalid Customer Id");
		}
	}

	@Override
	public String deleteCustomer(int custId) throws CustomerNotFound {
		if (customers.containsKey(custId)) {
			customers.remove(custId);
			return "Customer Deleted Successfully";
		} else {
			throw new CustomerNotFound("Invalid Customer Id");
		}
	}

	@Override
	public Customer getCustomer(int custId) throws CustomerNotFound {
		if (customers.containsKey(custId)) {
			return customers.get(custId);
		} else {
			throw new CustomerNotFound("Invalid Customer Id");
		}

	}

	@Override
	public Set<Customer> getAllCustomers() {
		Set<Integer> set = customers.keySet();
		Set<Customer> cust = new HashSet<Customer>();
		Iterator<Integer> keys = set.iterator();
		while (keys.hasNext()) {
			int key = keys.next();
			cust.add(customers.get(key));
		}
		return cust;
	}

}
